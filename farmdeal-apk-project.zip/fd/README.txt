FARMDEAL - GET YOUR APK (no Android Studio needed)

1. Create a free account at github.com and make a NEW repository
   (name it farmdeal, keep it Public or Private).
2. Unzip this file. In your new repository click
   "Add file" > "Upload files", drag in EVERYTHING from the unzipped
   folder (including the .github folder, www folder, package.json,
   capacitor.config.json), then click "Commit changes".
   Make sure the branch is named "main".
3. Open the "Actions" tab. The "Build APK" job starts by itself
   (or click it > "Run workflow"). Wait about 5-8 minutes for a green tick.
4. Open the finished run, scroll to "Artifacts", download "FarmDeal-APK".
   Unzip it: app-debug.apk is your app.
5. Send the APK to your phone and open it. If asked, allow
   "Install unknown apps".

To change the app later: edit www/index.html, commit, and download the
new APK from Actions again.

Note: this is a debug APK, fine for sharing and testing. Publishing on
Google Play needs a signed release build (AAB) and a Play developer account.
